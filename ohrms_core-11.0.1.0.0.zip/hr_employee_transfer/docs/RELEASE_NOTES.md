## Module hr_employee_transfer

#### 25.01.2019
#### Version 11.2.1.0.0
##### ADD
- validation modification to admin

#### 21.04.2018
#### Version 11.0.1.0.0
##### ADD
- Initial commit for OpenHrms Project


#### 18.12.2018
#### Version 11.0.2.0.0
##### UPDT
- Filters Added on the view
- Validations Added on the cancellation and transfer
