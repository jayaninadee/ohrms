## Module <hr_reward_warning>

#### 21.04.2018
#### Version 11.0.1.0.0
##### ADD
- Initial commit for Open HRMS Project

#### 17.12.2018
#### Version 11.0.2.0.0
##### UPDT
- Separate sequences for general and other announcements
- Extra fields in announcement
- Removed the done state from announcement